host = '0.0.0.0'
debug = False
logfile = '/home/rmb/app.log'
db_conf = {
    'user': 'rmb',
    'password': 'aaaaaaaaaaaaaaaaaaa',
    'host': '127.0.0.1',
    'database': 'rmb'
}
