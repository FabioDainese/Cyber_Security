RMB
===
Roll My Beats.

Setup
-----
Prepare the Python virtualenv
 
    $ mkdir -p ~/.venvs/
    $ virtualenv -p /usr/bin/python3 ~/.venvs/rmb
    $ . ~/.venvs/rmb/bin/activate

Install the dependencies

    (rmb)$ pip install flask PyMySQL

Enjoy!